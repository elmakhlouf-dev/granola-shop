
window.PRODUCTS = [
  {
    "id":"atlas-almond-honey",
    "name":"Atlas Almond & Honey Granola",
    "price": 7.90,
    "image":"https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?q=80&w=1600&auto=format&fit=crop",
    "desc":"Crunchy almond clusters baked with wildflower honey and pure vanilla.",
    "weight":"350 g",
    "tags":["classic","honey","almond"]
  },
  {
    "id":"date-walnut-cinnamon",
    "name":"Date Walnut Cinnamon",
    "price": 8.50,
    "image":"https://images.unsplash.com/photo-1541782814453-5bf75c90ca12?q=80&w=1600&auto=format&fit=crop",
    "desc":"Soft date bites, toasted walnuts and warm cinnamon — a cozy blend.",
    "weight":"350 g",
    "tags":["vegan","walnut","date"]
  },
  {
    "id":"argan-cacao-crunch",
    "name":"Argan Cacao Crunch",
    "price": 8.90,
    "image":"https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?q=80&w=1600&auto=format&fit=crop",
    "desc":"Moroccan argan oil, organic cacao nibs and sea salt — indulgent and balanced.",
    "weight":"350 g",
    "tags":["cacao","argan","gourmet"]
  }
];
