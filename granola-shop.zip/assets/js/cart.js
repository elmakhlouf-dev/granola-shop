
// Basic cart with localStorage
const CART_KEY = 'granola_cart_v1';

function getCart(){ try{return JSON.parse(localStorage.getItem(CART_KEY) || '[]')}catch(e){return []} }
function saveCart(items){ localStorage.setItem(CART_KEY, JSON.stringify(items)); updateCartCount(); }
function updateCartCount(){ const n = getCart().reduce((a,i)=>a+i.qty,0); const el = document.getElementById('cart-count'); if(el){ el.textContent = n || 0; } }
function formatPrice(n){ return new Intl.NumberFormat(undefined,{style:'currency',currency:'USD'}).format(n); }

function addToCart(id, qty=1){
  const items = getCart();
  const found = items.find(i=>i.id===id);
  if(found){ found.qty += qty; } else { items.push({id, qty}); }
  saveCart(items);
  alert('Added to cart');
}

function removeFromCart(id){
  saveCart(getCart().filter(i=>i.id!==id));
  renderCart();
}

function setQty(id, qty){
  const items = getCart();
  const item = items.find(i=>i.id===id);
  if(item){ item.qty = Math.max(1, qty|0); saveCart(items); renderCart(); }
}

function findProduct(id){ return (window.PRODUCTS||[]).find(p=>p.id===id); }

function renderShop(listSelector){
  const list = document.querySelector(listSelector);
  if(!list) return;
  (window.PRODUCTS||[]).forEach(p=>{
    const card = document.createElement('article');
    card.className='card';
    card.innerHTML = `
      <img src="${p.image}" loading="lazy" alt="${p.name}">
      <h3>${p.name}</h3>
      <p class="muted">${p.desc}</p>
      <div class="actions">
        <span class="price">${formatPrice(p.price)}</span>
        <a class="btn" href="product.html?id=${p.id}">View</a>
        <button class="btn" onclick="addToCart('${p.id}',1)">Add</button>
      </div>`;
    list.appendChild(card);
  });
}

function renderProduct(){
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  const p = findProduct(id) || (window.PRODUCTS||[])[0];
  if(!p) return;
  document.getElementById('p-img').src = p.image;
  document.getElementById('p-title').textContent = p.name;
  document.getElementById('p-desc').textContent = p.desc;
  document.getElementById('p-weight').textContent = p.weight;
  document.getElementById('p-price').textContent = formatPrice(p.price);
  document.getElementById('add-btn').onclick = ()=>{
    const q = parseInt(document.getElementById('qty').value||'1',10);
    addToCart(p.id, q);
  }
}

function renderCart(){
  const body = document.getElementById('cart-body');
  const totalEl = document.getElementById('cart-total');
  if(!body || !totalEl) return;
  body.innerHTML='';
  let total=0;
  getCart().forEach(i=>{
    const p = findProduct(i.id);
    if(!p) return;
    const line = p.price * i.qty;
    total += line;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><img src="${p.image}" alt="" style="width:60px;height:60px;object-fit:cover;border-radius:10px;margin-right:8px;vertical-align:middle;"> ${p.name}</td>
      <td>${formatPrice(p.price)}</td>
      <td>
        <input type="number" min="1" value="${i.qty}" style="width:70px" onchange="setQty('${i.id}', this.value)">
      </td>
      <td>${formatPrice(line)}</td>
      <td><button class="btn" onclick="removeFromCart('${i.id}')">Remove</button></td>
    `;
    body.appendChild(tr);
  });
  totalEl.textContent = formatPrice(total);
}

window.updateCartCount = updateCartCount;
